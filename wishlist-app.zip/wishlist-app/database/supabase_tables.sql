-- Supabase tables for Wishlist App

-- Users table
create table users (
  id uuid primary key default uuid_generate_v4(),
  email text unique not null,
  password text not null,
  created_at timestamp with time zone default timezone('utc'::text, now()),
  updated_at timestamp with time zone default timezone('utc'::text, now())
);

-- Wishlists table
create table wishlists (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  description text,
  created_by uuid references users(id) on delete cascade,
  created_at timestamp with time zone default timezone('utc'::text, now()),
  updated_at timestamp with time zone default timezone('utc'::text, now())
);

-- Wishlist items table
create table wishlist_items (
  id uuid primary key default uuid_generate_v4(),
  wishlist_id uuid references wishlists(id) on delete cascade,
  product_id uuid not null,
  product_title text not null,
  product_price numeric not null,
  product_image text not null,
  product_description text not null,
  product_category text not null,
  product_rating numeric not null,
  added_by uuid references users(id) on delete cascade,
  created_at timestamp with time zone default timezone('utc'::text, now()),
  updated_at timestamp with time zone default timezone('utc'::text, now())
);

-- Likes table
create table likes (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references users(id) on delete cascade,
  item_id uuid references wishlist_items(id) on delete cascade,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- Comments table
create table comments (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references users(id) on delete cascade,
  item_id uuid references wishlist_items(id) on delete cascade,
  content text not null,
  created_at timestamp with time zone default timezone('utc'::text, now())
);
